// JS CODE TO CALC CUBEROOT

const cr = 27;
const cubeRoot = Math.cbrt(cr);
console.log(`the cube root is: ${cubeRoot}`);
